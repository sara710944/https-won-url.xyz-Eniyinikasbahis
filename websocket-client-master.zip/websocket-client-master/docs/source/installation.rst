############
Installation
############

You can use either ``pip install websocket-client`` or
``pip install -e .`` to install this library.
