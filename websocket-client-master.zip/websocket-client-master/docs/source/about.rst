#####
About
#####

The websocket-client project was started in 2011, but experienced a slowdown in
development in 2019-2020. The original creator of this project was
`liris <https://github.com/liris>`_ and the current maintainer (since 2021) is
`engn33r <https://github.com/engn33r>`_. The project is in the process of being
rejuvenated, so any edits or suggestions are appreciated. No typo is too small
for a pull request! See the :ref:`contributing` page for more info.
