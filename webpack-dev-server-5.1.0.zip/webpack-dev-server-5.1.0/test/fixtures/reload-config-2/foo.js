"use strict";

// eslint-disable-next-line import/no-unresolved
require("./main.css");
