"use strict";

console.log("Bar.");
