"use strict";

console.log("Hey.");
