"use strict";

module.exports = {
  mode: "development",
  stats: "detailed",
  context: __dirname,
  entry: "./foo.js",
};
