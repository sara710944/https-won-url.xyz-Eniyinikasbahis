"use strict";

console.log("two");
