"use strict";

console.log("one");
