"use strict";

require("./file.custom");

console.log("Hey.");
