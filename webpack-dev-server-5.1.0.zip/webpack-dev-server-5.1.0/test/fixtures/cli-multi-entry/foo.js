"use strict";

console.log("I am foo");
