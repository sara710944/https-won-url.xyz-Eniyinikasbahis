"use strict";

console.log("I am bar");
