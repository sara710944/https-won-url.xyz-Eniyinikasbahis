"use strict";

console.log("i am foo!");
