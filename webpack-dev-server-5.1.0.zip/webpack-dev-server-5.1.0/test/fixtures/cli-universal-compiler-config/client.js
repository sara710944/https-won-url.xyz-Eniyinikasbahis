"use strict";

console.log("Hello from the client");
