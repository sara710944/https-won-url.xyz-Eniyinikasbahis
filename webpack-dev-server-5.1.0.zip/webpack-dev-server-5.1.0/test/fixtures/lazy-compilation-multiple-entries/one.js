"use strict";

console.log("One.");
