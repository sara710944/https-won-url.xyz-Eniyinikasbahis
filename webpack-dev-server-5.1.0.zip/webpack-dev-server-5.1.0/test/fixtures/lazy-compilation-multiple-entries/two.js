"use strict";

console.log("Two.");
