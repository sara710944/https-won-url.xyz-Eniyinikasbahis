"use strict";

require("./index.html");
require("./bar.html");

console.log("Hey.");
