"use strict";

module.exports = "entry1";
