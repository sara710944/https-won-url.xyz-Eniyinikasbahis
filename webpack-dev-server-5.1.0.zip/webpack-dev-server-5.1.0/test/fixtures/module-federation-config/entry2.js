"use strict";

module.exports = "entry2";
