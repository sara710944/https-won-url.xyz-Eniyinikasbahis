"use strict";

require("./test.html");
