"use strict";

require("./main.css");
