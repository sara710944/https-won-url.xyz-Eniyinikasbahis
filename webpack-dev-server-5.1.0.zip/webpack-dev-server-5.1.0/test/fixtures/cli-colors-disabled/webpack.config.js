"use strict";

module.exports = {
  mode: "development",
  stats: {
    colors: false,
  },
  context: __dirname,
  entry: "./foo.js",
  infrastructureLogging: {
    colors: false,
  },
};
