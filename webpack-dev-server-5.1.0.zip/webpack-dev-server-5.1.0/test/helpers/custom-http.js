"use strict";

const customHTTP = require("http");

module.exports = customHTTP;
