"use strict";

// Change the following line and save to see the compilation status

const target = document.querySelector("#target");

target.classList.add("pass");
target.innerHTML = "Success!";
