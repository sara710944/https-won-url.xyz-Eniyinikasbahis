"use strict";

console.log("webpack-dev-server/server");
