"use strict";

const target = document.querySelector("#target");

target.classList.add("pass");
target.innerHTML = "Success! Now visit <a href='/proxy'>/proxy</a>";
