"use strict";

const target = document.querySelector("#target");

target.innerHTML = "Please check your Zeroconf service.";
