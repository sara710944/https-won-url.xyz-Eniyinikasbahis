"use strict";

const target = document.querySelector("#target");

target.innerHTML =
  "Please check the ws request in devtools, it should try to connect to the protocol + server defined in the webSocketURL setting.";
