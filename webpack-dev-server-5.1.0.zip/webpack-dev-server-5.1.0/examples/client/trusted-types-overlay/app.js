"use strict";

const target = document.querySelector("#target");

target.classList.add("pass");
target.textContent = "Success!";

// To display an overlay with an error
(
