"use strict";

const target = document.querySelector("#target");

target.classList.add("pass");
target.innerHTML = "Success! Reload the page after 5 seconds.";
