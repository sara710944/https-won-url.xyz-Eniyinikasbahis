"use strict";

const target = document.querySelector("#target");

target.innerHTML =
  "Modify and save <code>/examples/hmr/example.js</code> to update this element without reloading the page.";
