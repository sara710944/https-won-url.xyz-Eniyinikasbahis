"use strict";

process.env.CHOKIDAR_USEPOLLING = true;

jest.setTimeout(400000);
