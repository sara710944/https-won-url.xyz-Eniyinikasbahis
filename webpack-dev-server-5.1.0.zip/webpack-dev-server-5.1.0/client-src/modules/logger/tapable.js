function SyncBailHook() {
  return {
    call() {},
  };
}

/**
 * Client stub for tapable SyncBailHook
 */
// eslint-disable-next-line import/prefer-default-export
export { SyncBailHook };
