export { default } from "webpack/lib/logging/runtime.js";
