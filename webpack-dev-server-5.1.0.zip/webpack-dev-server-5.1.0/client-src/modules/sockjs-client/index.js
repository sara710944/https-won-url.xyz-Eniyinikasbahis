// eslint-disable-next-line import/no-extraneous-dependencies
export { default } from "sockjs-client";
