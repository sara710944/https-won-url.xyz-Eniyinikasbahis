---
name: ✨ Feature Request
about: Suggest an idea for this project
---

<!-- Please don't delete this template otherwise your issue will be closed immediately -->
<!-- Before creating an issue please make sure you are using the latest version of webpack. -->

### Feature Proposal

<!-- Please ask questions on discussions or StackOverflow. -->
<!-- https://github.com/webpack/webpack/discussions -->
<!-- https://stackoverflow.com/questions/ask?tags=webpack -->
<!-- Issues which contain questions or support requests will be closed. -->

### Feature Use Case

### Please paste the results of `npx webpack-cli info` here, and mention other relevant information
