## Code of Conduct

At webpack and webpack/webpack-dev-server repository we follow the [JSFoundation Code of Conduct][1].
Please adhere to the guidelines there and feel free to report any violation of them to the **@webpack/core-team**,
**@webpack/dev-server-team**, or <conduct@js.foundation>.

[1]: https://github.com/openjs-foundation/code-and-learn/blob/main/CODE_OF_CONDUCT.md
